---
hide_table_of_contents: false
title: Binance
description: Binance
tags:
  - quant
  - tradingview
  - python
  - ema
---

# Binance

## API Keys | Whitelist IP

**Copy and Paste to the API Keys**

<Image img={require("/img/trader/api-keys/ip_access.png")} />

```
35.234.241.52 35.203.55.44 34.95.27.45
```

**Enable the following permissions**

<Image img={require("/img/trader/api-keys/secret_key.png")} />

## Setup for Futures

Wallet Setup

💡 Click the `Wallet` and select `Futures`

<Image img={require("/img/trader/binance/wallet.png")} />

<Image img={require("/img/trader/binance/futures.png")} />

💡 Check if `USD-M` has enough balance if not hit `Transfer`

<Image img={require("/img/trader/binance/USD-M.png")} />

<Image img={require("/img/trader/binance/Transfer.png")} />

<Image img={require("/img/trader/binance/USD-M-Futures.png")} />
