---
sidebar_position: 1
sidebar_label: log
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# log

To print the message with at most 200 characters. It only shows the lastest 500# messages.


## Input

```typescript
  message: string;
```

## Example

To print open, close and volume.

```python
exchange, pair, base, quote = CA.get_exchange_pair()
CA.log(str(candles[exchange][pair][0]['open']))
CA.log(str(candles[exchange][pair][0]['close']))
CA.log(str(candles[exchange][pair][0]['volume']))
```

To print available base and quot amount.

```python
exchange, pair, base, quote = CA.get_exchange_pair()
base_balance = CA.get_balance(exchange, base)
quote_balance = CA.get_balance(exchange, quote)
available_base_amount = base_balance.available
available_quote_amount = quote_balance.available
total_base_amount = base_balance.total
total_quote_amount = quote_balance.total
CA.log('available ' + str(base) + ' amount: ' + str(available_base_amount))
CA.log('available ' + str(quote) + ' amount: ' + str(available_quote_amount))
CA.log('total ' + str(base) + ' amount: ' + str(total_base_amount))
CA.log('total ' + str(quote) + ' amount: ' + str(total_quote_amount))
```
