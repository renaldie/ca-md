---
sidebar_position: 16
sidebar_label: storage
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# storage

To set key and value.

## Input

To set key and value.

```typescript
key: string;
value: any;
```

To access key

```typescript
key: string;
```

## Return

```typescript
value: string;
```

## Example

```python
CA.storage('string', 'to the moon 🌙')
val = CA.storage('string') # to the moon 🌙
CA.storage('int', 131441)
val = CA.storage('int') # 131441
CA.storage('none', None)
val = CA.storage('none') # None
```
