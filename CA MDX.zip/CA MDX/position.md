---
sidebar_position: 7
sidebar_label: Position
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# Position

### `exchange: Exchange`

**Exchange** 

e.g. Binance

### `pair: string`

**Pair name**

e.g. BTC/USDT

### `position_side: string`

**Position Side**

e.g. LONG, SHORT

### `total_size: float`

**Total Size**

e.g. 1.0

### `available_size: float`

**Available Size**

> When closing a LONG position with a LIMIT order, available size will decrement to prevent over-closing while total size will remain the same before the LIMIT order is FILLED

e.g. 0.5

### `entry_price: float`

**Entry price**

e.g. 1500

### `mark_price: float`

**Mark price (use market price)**

e.g. 1500

### `margin: float`

**Margin**

e.g. 1500

### `liquidation_price: float`

**Liquidation price**

e.g. 100

### `profit_and_loss: float`

**Profit and loss**

e.g. 10
