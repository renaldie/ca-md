---
sidebar_position: 1
sidebar_label: Concept
hide_title: false
---

import { Highlight } from "../../../src/components/Highlight.js";

# Concept

<Highlight color="#ffba00"> In Progress </Highlight>
