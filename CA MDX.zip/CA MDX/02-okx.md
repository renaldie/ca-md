# OKX Testnet

登入 OKX 交易所，點選 [交易] -> [模擬交易]


點 [設定 (交易/市場資訊右邊第二個圖示)] 


點第一個 [賬戶模式]


設定為 [單幣種保證金模式]


點右上角 [用戶 (資產管理一模擬交易右邊的圖示)] -> [模擬交易 API]


點 [申請模擬交易V5 API] 創建 API


到 CryptoArsenal Profile 頁面，點 [API Key] -> [manage]


 

選擇 OKX(Demo trading)，輸入剛剛創建的 API key

