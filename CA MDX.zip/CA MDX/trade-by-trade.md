
import Image from '@theme/IdealImage';

# Trade By Trade

## Requires editing Pinescript