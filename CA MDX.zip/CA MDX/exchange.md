---
sidebar_position: 1
sidebar_label: Exchange
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# Exchange

### `name: string`

**Name**

e.g. Binance
