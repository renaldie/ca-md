---
sidebar_position: 6
sidebar_label: Webhook Setup
hide_title: false
---

import { Highlight } from "../../../../src/components/Highlight.js";

# TradingView Webhook Setup

<Highlight color="#ffba00"> Beta </Highlight>

## Automate TradingView Strategy

🎥 See the [Tutorial Video](https://www.loom.com/share/d55eb875b562463ea8f18f78a0f8d4b0?sid=aa433e8f-6557-4935-ac4b-222e8f552861)

See [how to live trade and simulate trade signals from a TV Strategy here](/docs/tradingview/strategy/sync-by-position)

## Automate TradingView Indicator Alerts

See [how to live trade and simulate trade signals from a TV Indicator Alerts here](/docs/tradingview/indicator)
