---
sidebar_position: 3
sidebar_label: LightGBM
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# LightGBM

We support LightGBM model with version `lightgbm==3.3.2`

Make sure that the model is trained with `lightgbm==3.3.2`. Dump the model with `joblib==1.1.0` and upload the pkl to the strategy.

> Learn more about the [strategy flow here](https://help.crypto-arsenal.io/en/articles/6406316-strategy-flow-ml-model)

**Your side**

```py
import joblib

joblib.dump(gmb, 'gmb.pkl')
```

**Crypto Arsenal**

```py
gmb = CA.get_source("my gmb model")
gmb.predict(...)
```


