---
sidebar_position: 5
sidebar_label: Order
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# Order

### `order_id: integer`

**Order ID**

e.g. 1626072888367

### `time: string`

**Time**

e.g. 2021-01-05T08:01:00.000Z

### `exchange: Exchange`

**Exchange** 

e.g. Binance

### `pair: ExchangePair` 

**Pair**

e.g. BTC-USDT

### `type: OrderType`

**Order type**

e.g. OrderType.LIMIT

### `status: OrderStatus` 

**Order status**

e.g. OrderStatus.FILLED

### `price: float`

**Price**

e.g. 25000

### `amount: float`

**Amount**

e.g. 1

### `amount_filled: float`

**Amount filled**

e.g. 0.5

