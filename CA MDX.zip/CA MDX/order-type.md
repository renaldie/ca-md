---
sidebar_position: 3
sidebar_label: OrderType
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# OrderType

### `LIMIT`

**Limit order**

### `MARKET`

**Market order**
