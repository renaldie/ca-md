---
sidebar_position: 11
sidebar_label: get_exchange
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# get_exchange

To get exchange information.

## Return

```
  exchange: Exchange
```

> Check [Exchange](/docs/developer/api/python/ca-objects/exchange)

## Example

To get exchange information.

```
exchange = CA.get_exchange()
```
