---
sidebar_position: 2
sidebar_label: ta-lib
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# ta-lib

Use `talib` to access [talib] function. (https://github.com/mrjbq7/ta-lib)

### Example

Use talib to calculate RSI.

```python
rsi = talib.RSI(self.close_price_trace, Len)[-1]
```
