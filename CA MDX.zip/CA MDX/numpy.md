---
sidebar_position: 1
sidebar_label: NumPy
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# NumPy

Use `np` to access [numpy] function. (http://www.numpy.org/)

### Example

Use np.append to append close price.

```python
close_price = float( candles[exchange][pair][0]['close'])
self.close_price_trace = np.append(self.close_price_trace, [close_price])
```
