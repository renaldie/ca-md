---
sidebar_position: 2
sidebar_label: ExchangePair
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# ExchangePair

### `exchange: Exchange`

**Exchange** 

e.g. Binance

### `pair: string`

**Pair**

e.g. BTC-USDT

### `base: string`

**Base currency**

e.g. BTC

### `quote: string`

**Quote currency**

e.g. USDT
