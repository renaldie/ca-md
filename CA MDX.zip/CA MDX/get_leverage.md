---
sidebar_position: 14
sidebar_label: get_leverage
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# get_leverage


## Input

```typescript
```

## Return

```typescript
  leverage: Int;
```

## Example

Note that `leverage` is only applicable to Futures

```python
exchange, pair, base, quote = CA.get_exchange_pair()
leverage = CA.get_leverage()
CA.place_order(exchange, pair, action='open_long', percent=100 * leverage)
```

