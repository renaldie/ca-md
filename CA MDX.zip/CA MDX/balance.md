---
sidebar_position: 6
sidebar_label: Balance
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# Balance

### `exchange: Exchange`

**Exchange** 

e.g. Binance

### `currency: string`

**Currency name**

e.g. BTC

### `available: float`

**Available asset**

e.g. 1.0

### `locked: float`

**Locked asset**

e.g. 0.5

### `total: float`

**Total asset**

e.g. 1.5
