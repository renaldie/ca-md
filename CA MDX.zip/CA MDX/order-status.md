---
sidebar_position: 4
sidebar_label: OrderStatus
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# OrderStatus

### `NEW`

**New**

### `PARTIALLY_FILLED`

**Partially filled**

### `FILLED`

**Filled**

### `CANCELED`

**Canceled**
