---
sidebar_position: 9
sidebar_label: cancel_order
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# cancel_order

<Highlight color="#ffba00"> This function can only be used in trade() or on_tradingview_signal().</Highlight>

## Input

```typescript
order: Order;
```

> Check [Order](/docs/developer/api/python/ca-objects/order)

## Example

To get the lastest 1 order with status as NEW, and cancel this order.

```python
orders = CA.get_orders(CA.OrderStatus.NEW, 1)
for order in orders:
    CA.cancel_order(order)
```

# cancel_order_by_client_order_id

<Highlight color="#ffba00"> This function can only be used in trade() or on_tradingview_signal().</Highlight>

## Input

```typescript
client_order_id: string;
```

## Example
```python
CA.cancel_order_by_client_order_id('order1')
```
