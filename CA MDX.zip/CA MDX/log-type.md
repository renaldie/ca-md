---
sidebar_position: 8
sidebar_label: LogType
hide_title: false
---

import { Highlight } from "../../../../../src/components/Highlight.js";

# LogType

### `DEBUG`

DEBUG

### `INFO`

INFO

### `NOTICE`

NOTICE

